# Web de Flow (chat + llamada de voz)

Web estática: no necesita servidor propio. Todo el audio (micrófono y voz) lo hace el navegador; no se sube ningún audio a ningún sitio.

## 1. Configurar (`js/config.js`)
- En `modelos` hay una entrada `tipo: "flowpi"`: pon en `apiUrl` la dirección https pública de la API de la Pi (Tailscale Funnel) y en `apiKey` una clave `flw_…` creada en la pestaña API del panel.
- Esa clave la verá cualquiera que abra la web: crea una SOLO para la web, con pocas peticiones por minuto, y bórrala si alguien abusa.
- En el panel de la Pi (pestaña API › orígenes permitidos) añade el origen de tu web, p. ej. `https://TU_USUARIO.github.io` (sin barra final ni ruta).
- Funnel para la API (ajusta el puerto si cambiaste el de la API): `tailscale funnel --bg --https=8443 8766`

## 2. Publicar en GitHub Pages (recomendado)
1. Crea un repositorio público nuevo y sube el contenido de esta carpeta (index.html, css/, js/, img/).
2. Settings › Pages › Deploy from a branch › `main` / `(root)`.
3. Tu web queda en `https://TU_USUARIO.github.io/NOMBRE-DEL-REPO/`. El origen para el panel es solo `https://TU_USUARIO.github.io`.
Es gratis, con https (el micrófono lo exige) y no se apaga. Wispbytes está pensado para ejecutar programas, no para páginas estáticas: no aporta nada aquí.

## 3. La llamada
- Botón de las ondas junto al campo de texto. Funciona en Chrome, Edge y Safari (Firefox no tiene reconocimiento de voz).
- Hablas → se transcribe → se envía → Flow contesta en voz alta → vuelve a escucharte. Todo queda también en el chat normal.
- Toca la flor para interrumpir a Flow o cancelar una respuesta. Esc cuelga.
- La voz se elige sola (la más natural instalada): «Natural» en Edge, «Google español» en Chrome, premium en Apple. Se puede cambiar en el botón de ajustes.

## 4. Modo admin
Pulsa A + D + M + I + N + R a la vez (sin ninguna otra tecla; en el móvil no hay forma). Sale una marca ADMIN arriba y se abre el panel: añadir, editar, probar, usar y quitar APIs, cambiar ajustes de la llamada y exportar/importar. Repite la combinación para salir.
Es solo comodidad, no seguridad: lo guardado vive en el navegador de quien lo hace y no cambia nada para los demás. Para cambiar la web de todos, edita js/config.js dentro del zip y vuelve a publicar.
