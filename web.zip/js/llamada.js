// Llamada de voz con Flow: hablas, el navegador transcribe, se envía el mensaje y la respuesta se lee en voz alta.
// Todo ocurre en el navegador (reconocimiento y síntesis de voz del propio sistema): no se sube ningún audio a este servidor.
(function () {
  "use strict";
  var C = window.FLOW_CONFIG || {}, L = C.llamada || {};
  var A = window.FlowApp;
  var btnLlamar = document.getElementById("llamar");
  if (!A || !btnLlamar) return;

  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var TTS = "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;
  var $ = function (id) { return document.getElementById(id); };
  var el = { raiz: $("llamada"), estado: $("llEstado"), flor: $("llFlor"), caja: $("llCaja"), textos: $("llTextos"), sub: $("llSub"), resp: $("llResp"),
    ajustes: $("llAjustes"), voz: $("llVoz"), vel: $("llVel"), velTxt: $("llVelTxt"), probar: $("llProbar"), nota: $("llNota"),
    mic: $("llMic"), subs: $("llSubs"), conf: $("llConf"), colgar: $("llColgar") };
  var reducir = window.matchMedia("(prefers-reduced-motion: reduce)");
  var movil = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || "");

  var enLlamada = false, estado = "off", turno = 0, genTTS = 0;
  var rec = null, silenciado = false, fallos = 0, ultimoInicio = 0, temporizador = null, fatal = "";
  var flor = null, raf = 0, amp = 0, ampObj = 0, nivel = 0, hablaDesde = 0;
  var flujoMic = null, ctxAudio = null, analizador = null, bufNivel = null, wake = null;
  var voces = [], vozElegida = null;
  var prefs = { voz: "auto", vel: 1, subs: true };
  try {
    prefs.voz = localStorage.getItem("flow_ll_voz") || "auto";
    prefs.vel = Math.min(1.3, Math.max(0.7, parseFloat(localStorage.getItem("flow_ll_vel")) || 1));
    prefs.subs = localStorage.getItem("flow_ll_subs") !== "0";
  } catch (e) {}
  function guardarPref(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }

  /* ---------- voces: se elige la más natural que haya instalada ---------- */
  function puntuar(v) {
    var n = (v.name || "").toLowerCase(), l = (v.lang || "").toLowerCase().replace("_", "-");
    if (l.indexOf("es") !== 0) return -1;
    var p = 0;
    if (/natural/.test(n)) p += 100;                       // Edge: «Microsoft Álvaro Online (Natural)» (voces neuronales)
    if (/neural|online/.test(n)) p += 60;
    if (/premium|enhanced|mejorada|siri/.test(n)) p += 70; // Apple
    if (/google/.test(n)) p += 40;                         // Chrome / Chromebook: «Google español»
    if (/microsoft/.test(n)) p += 20;
    if (/compact|espeak|festival|pico/.test(n)) p -= 60;
    p += l === "es-es" ? 12 : (l === "es-mx" || l === "es-us") ? 8 : 4;
    if (L.vozPreferida && new RegExp(L.vozPreferida, "i").test(v.name)) p += 500;
    return p;
  }
  function cargarVoces() {
    if (!TTS) return;
    var todas = window.speechSynthesis.getVoices() || [];
    voces = todas.map(function (v) { return { v: v, p: puntuar(v) }; }).filter(function (x) { return x.p >= 0; }).sort(function (a, b) { return b.p - a.p; });
    elegirVoz(); pintarVoces();
  }
  function elegirVoz() {
    vozElegida = null;
    if (prefs.voz !== "auto") { var x = voces.filter(function (o) { return o.v.voiceURI === prefs.voz; })[0]; if (x) { vozElegida = x.v; return; } }
    if (voces.length) vozElegida = voces[0].v;
  }
  function pintarVoces() {
    el.voz.textContent = "";
    var auto = document.createElement("option"); auto.value = "auto"; auto.textContent = "Automática" + (voces.length ? " (" + voces[0].v.name + ")" : ""); el.voz.appendChild(auto);
    voces.forEach(function (o) { var op = document.createElement("option"); op.value = o.v.voiceURI; op.textContent = o.v.name + " · " + o.v.lang; el.voz.appendChild(op); });
    el.voz.value = prefs.voz; if (el.voz.value !== prefs.voz) el.voz.value = "auto";
    var mejor = voces.length ? voces[0].p : -1;
    el.nota.textContent = !voces.length ? "Este navegador no tiene voces en español: Flow te contestará solo por escrito."
      : mejor < 100 ? "Suenan mejor las voces «Natural» de Microsoft Edge y «Google español» de Chrome. En Windows también puedes añadir voces en Configuración › Hora e idioma › Voz."
      : "Estás usando una voz neuronal: es la que mejor suena.";
  }
  if (TTS) { cargarVoces(); window.speechSynthesis.addEventListener("voiceschanged", cargarVoces); setTimeout(cargarVoces, 800); }

  /* ---------- texto que se lee: sin marcas de herramientas ni símbolos ---------- */
  function paraLeer(t) {
    return String(t).replace(/\[\[[\s\S]*?\]\]/g, " ").replace(/https?:\/\/\S+/g, " ").replace(/[*_`#>~|]+/g, " ")
      .replace(/(\d)\s*%/g, "$1 por ciento").replace(/\s+/g, " ").trim();
  }
  function trocear(t) {            // frases cortas: Chrome corta las locuciones largas a los ~15 s
    var partes = t.match(/[^.!?…;:\n]+[.!?…;:]*\s*/g) || [t], out = [];
    partes.forEach(function (p) {
      p = p.trim(); if (!p) return;
      while (p.length > 180) {
        var i = p.lastIndexOf(",", 180); if (i < 50) i = p.lastIndexOf(" ", 180); if (i < 1) i = 180;
        out.push(p.slice(0, i + 1).trim()); p = p.slice(i + 1).trim();
      }
      if (p) out.push(p);
    });
    var fin = [];
    out.forEach(function (p) { if (fin.length && fin[fin.length - 1].length < 25) fin[fin.length - 1] += " " + p; else fin.push(p); });
    return fin;
  }

  function hablar(texto, alTerminar) {
    var g = ++genTTS, partes = trocear(paraLeer(texto)), i = 0, wd = null;
    if (!TTS || !partes.length) { if (alTerminar) alTerminar(); return; }
    try { window.speechSynthesis.cancel(); } catch (e) {}
    function fin() { clearTimeout(wd); if (g === genTTS) { ampObj = 0; if (alTerminar) alTerminar(); } }
    function siguiente() {
      if (g !== genTTS) return;
      if (i >= partes.length) return fin();
      var frase = partes[i++], u = new SpeechSynthesisUtterance(frase), hecho = false;
      el.resp.textContent = frase;
      u.lang = vozElegida ? vozElegida.lang : "es-ES"; if (vozElegida) u.voice = vozElegida;
      u.rate = prefs.vel; u.pitch = 1;
      var sigue = function () { if (hecho) return; hecho = true; clearTimeout(wd); siguiente(); };
      u.onstart = function () { ampObj = Math.max(ampObj, .6); };
      u.onboundary = function () { ampObj = 1; };
      u.onend = sigue; u.onerror = function (ev) { if (g !== genTTS) return; sigue(); };
      wd = setTimeout(sigue, 5000 + frase.length * 130);     // por si el navegador no avisa del final
      try { window.speechSynthesis.speak(u); } catch (e) { sigue(); }
    }
    setTimeout(siguiente, 60);
    return g;
  }
  function callar() { genTTS++; ampObj = 0; if (TTS) { try { window.speechSynthesis.cancel(); } catch (e) {} } }

  /* ---------- estados y animación ---------- */
  var ETIQUETA = { inicio: "Conectando…", escuchando: "Escuchando…", pensando: "Pensando…", hablando: "Flow está hablando", pausa: "Micrófono silenciado", error: "" };
  function poner(e) {
    estado = e;
    el.caja.classList.remove("escuchando", "hablando", "pausa");
    if (e === "escuchando" || e === "hablando" || e === "pausa") el.caja.classList.add(e);
    if (flor) flor.classList.toggle("pensando", e === "pensando");
    el.estado.textContent = e === "error" ? fatal : (ETIQUETA[e] || "");
    el.flor.setAttribute("aria-label", e === "hablando" ? "Flow está hablando. Toca para interrumpir" : e === "pensando" ? "Flow está pensando. Toca para cancelar" : e === "error" ? "Toca para reintentar" : "Flow");
    if (e === "hablando") hablaDesde = performance.now();
  }
  function bucle(t) {
    if (!enLlamada) return;
    raf = requestAnimationFrame(bucle);
    var quieto = reducir.matches, a = 0, n = 0;
    if (estado === "hablando") {                  // la voz no da su volumen: se simula una envolvente de sílabas y los eventos de palabra la refuerzan
      var s = (t - hablaDesde) / 1000;
      var env = .32 + .34 * Math.abs(Math.sin(s * 7.3)) * (.65 + .35 * Math.sin(s * 2.1 + 1));
      ampObj *= .93; a = Math.max(env, ampObj) * (quieto ? .3 : 1);
    } else if (estado === "pensando") { a = quieto ? 0 : .22 + .18 * Math.sin(t / 420); }
    amp += (a - amp) * .25;
    if (estado === "escuchando" && analizador) {
      analizador.getByteTimeDomainData(bufNivel);
      var suma = 0; for (var i = 0; i < bufNivel.length; i++) { var d = (bufNivel[i] - 128) / 128; suma += d * d; }
      n = Math.min(1, Math.sqrt(suma / bufNivel.length) * 5);
    }
    nivel += (n - nivel) * .3;
    el.caja.style.setProperty("--amp", amp.toFixed(3));
    el.caja.style.setProperty("--nivel", (quieto ? nivel * .3 : nivel).toFixed(3));
  }

  /* ---------- micrófono: volumen para animar la flor y aviso de permiso ---------- */
  async function abrirMic() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return true;
    if (movil && L.nivelMic !== true) return true;   // en el móvil el reconocimiento y un segundo acceso al micro suelen pelearse
    try {
      flujoMic = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    } catch (e) {
      if (e && (e.name === "NotAllowedError" || e.name === "SecurityError")) { fatal = "Permiso de micrófono denegado. Actívalo en el candado de la barra de direcciones y vuelve a llamar."; return false; }
      if (e && e.name === "NotFoundError") { fatal = "No se detecta ningún micrófono."; return false; }
      return true;
    }
    try {
      var AC = window.AudioContext || window.webkitAudioContext; ctxAudio = new AC();
      analizador = ctxAudio.createAnalyser(); analizador.fftSize = 512; bufNivel = new Uint8Array(analizador.fftSize);
      ctxAudio.createMediaStreamSource(flujoMic).connect(analizador);
    } catch (e) { analizador = null; }
    return true;
  }
  function cerrarMic() {
    if (flujoMic) flujoMic.getTracks().forEach(function (t) { t.stop(); }); flujoMic = null;
    if (ctxAudio) { try { ctxAudio.close(); } catch (e) {} } ctxAudio = null; analizador = null;
  }

  /* ---------- reconocimiento de voz ---------- */
  function escuchar() {
    clearTimeout(temporizador); temporizador = null;
    if (!enLlamada) return;
    if (silenciado) { poner("pausa"); return; }
    poner("escuchando");
    if (rec) return;
    var ahora = Date.now();
    fallos = (ahora - ultimoInicio < 1200) ? fallos + 1 : 0; ultimoInicio = ahora;
    if (fallos >= 6) { fatal = "No consigo oírte. Mira que el micrófono funciona y toca la flor para reintentar."; fallos = 0; poner("error"); return; }
    var r = new SR(), fin = "", prov = "", miTurno = turno;
    r.lang = L.idioma || "es-ES"; r.interimResults = true; r.continuous = false; r.maxAlternatives = 1;
    r.onresult = function (ev) {
      prov = "";
      for (var i = ev.resultIndex; i < ev.results.length; i++) { var x = ev.results[i]; if (x.isFinal) fin += x[0].transcript; else prov += x[0].transcript; }
      el.sub.textContent = (fin + prov).trim(); el.resp.textContent = "";
    };
    r.onerror = function (ev) {
      var c = ev && ev.error;
      if (c === "not-allowed" || c === "service-not-allowed") fatal = "Permiso de micrófono denegado. Actívalo en el candado de la barra de direcciones.";
      else if (c === "audio-capture") fatal = "No se detecta ningún micrófono.";
      else if (c === "network") fatal = "El reconocimiento de voz del navegador necesita conexión a Internet.";
      else if (c === "language-not-supported") fatal = "Tu navegador no reconoce el español.";
      else return;                          // no-speech / aborted: se vuelve a escuchar en onend
      fallos = 0; rec = null; if (enLlamada) poner("error");
    };
    r.onend = function () {
      if (rec === r) rec = null;
      if (!enLlamada || estado !== "escuchando" || miTurno !== turno) return;
      var t = (fin || prov).trim();
      if (t.length >= 2) responder(t);
      else temporizador = setTimeout(escuchar, 250);
    };
    rec = r;
    try { r.start(); } catch (e) { rec = null; temporizador = setTimeout(escuchar, 500); }
  }
  function pararEscucha() { clearTimeout(temporizador); temporizador = null; var r = rec; rec = null; if (r) { r.onend = r.onerror = r.onresult = null; try { r.abort(); } catch (e) {} } }

  /* ---------- un turno: lo que dices → Flow → voz ---------- */
  function responder(dicho) {
    var t = ++turno; pararEscucha();
    el.sub.textContent = dicho; el.resp.textContent = "";
    poner("pensando");
    A.enviar(dicho, function (resp, error) {
      if (!enLlamada || t !== turno) return;
      var dicha = error ? "No he podido responder. " + resp : resp;
      el.resp.textContent = resp;
      poner("hablando");
      hablar(dicha, function () { if (enLlamada && t === turno) { poner("escuchando"); temporizador = setTimeout(escuchar, 350); } });
    }).then(function (r) {
      if (!enLlamada || t !== turno || estado !== "pensando") return;
      temporizador = setTimeout(escuchar, 600);     // la petición se canceló o había otra en marcha
    });
  }

  /* ---------- abrir y cerrar la llamada ---------- */
  async function llamar() {
    if (enLlamada) return;
    if (!SR) { A.avisar("Tu navegador no reconoce la voz. Usa Chrome, Edge o Safari."); return; }
    if (!window.isSecureContext) { A.avisar("La llamada solo funciona en una dirección segura (https)."); return; }
    if (A.ocupado()) { A.avisar("Espera a que Flow termine de responder."); return; }
    enLlamada = true; turno++; fatal = ""; silenciado = false; fallos = 0;
    el.raiz.hidden = false; document.body.style.overflow = "hidden";
    el.sub.textContent = ""; el.resp.textContent = ""; el.ajustes.hidden = true; el.conf.setAttribute("aria-pressed", "false");
    pintarBotones();
    el.caja.textContent = ""; flor = A.florAnimada(); el.caja.appendChild(flor);
    poner("inicio"); el.colgar.focus();
    cancelAnimationFrame(raf); raf = requestAnimationFrame(bucle);
    try { if (navigator.wakeLock) wake = await navigator.wakeLock.request("screen"); } catch (e) { wake = null; }
    var ok = await abrirMic();
    if (!enLlamada) { cerrarMic(); return; }
    if (!ok) { poner("error"); return; }
    var saludo = L.saludo === undefined ? "Hola, soy Flow. Te escucho." : L.saludo;
    if (TTS && vozElegida && saludo) { poner("hablando"); el.resp.textContent = saludo; var t0 = turno; hablar(saludo, function () { if (enLlamada && t0 === turno) { poner("escuchando"); temporizador = setTimeout(escuchar, 300); } }); }
    else escuchar();
  }
  function colgar() {
    if (!enLlamada) return;
    enLlamada = false; turno++; clearTimeout(temporizador); pararEscucha(); callar(); A.cancelar(); cerrarMic();
    cancelAnimationFrame(raf); amp = nivel = 0;
    if (wake) { try { wake.release(); } catch (e) {} wake = null; }
    el.raiz.hidden = true; document.body.style.overflow = ""; poner("off");
    btnLlamar.focus();
  }

  /* ---------- controles ---------- */
  function pintarBotones() {
    el.mic.setAttribute("aria-pressed", String(silenciado));
    el.mic.setAttribute("aria-label", silenciado ? "Activar micrófono" : "Silenciar micrófono"); el.mic.title = el.mic.getAttribute("aria-label");
    el.subs.setAttribute("aria-pressed", String(prefs.subs)); el.textos.classList.toggle("oculto", !prefs.subs);
    el.vel.value = prefs.vel; el.velTxt.textContent = (prefs.vel + "").replace(".", ",") + "×";
  }
  el.mic.addEventListener("click", function () {
    silenciado = !silenciado; pintarBotones();
    if (silenciado) { pararEscucha(); if (estado === "escuchando") poner("pausa"); }
    else if (estado === "pausa") escuchar();
  });
  el.subs.addEventListener("click", function () { prefs.subs = !prefs.subs; guardarPref("flow_ll_subs", prefs.subs ? "1" : "0"); pintarBotones(); });
  el.conf.addEventListener("click", function () { var abrir = el.ajustes.hidden; el.ajustes.hidden = !abrir; el.conf.setAttribute("aria-pressed", String(abrir)); });
  el.voz.addEventListener("change", function () { prefs.voz = el.voz.value; guardarPref("flow_ll_voz", prefs.voz); elegirVoz(); });
  el.vel.addEventListener("input", function () { prefs.vel = parseFloat(el.vel.value) || 1; guardarPref("flow_ll_vel", String(prefs.vel)); pintarBotones(); });
  el.probar.addEventListener("click", function () {
    var antes = estado; pararEscucha(); poner("hablando");
    hablar("Hola, soy Flow. Así sueno con esta voz.", function () { if (enLlamada && antes !== "pausa") { poner("escuchando"); temporizador = setTimeout(escuchar, 350); } else if (enLlamada) poner("pausa"); });
  });
  el.flor.addEventListener("click", function () {
    if (estado === "hablando") { turno++; callar(); poner("escuchando"); temporizador = setTimeout(escuchar, 250); }
    else if (estado === "pensando") { turno++; A.cancelar(); poner("escuchando"); temporizador = setTimeout(escuchar, 250); }
    else if (estado === "error") { fatal = ""; fallos = 0; escuchar(); }
  });
  el.colgar.addEventListener("click", colgar);
  btnLlamar.addEventListener("click", llamar);
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && enLlamada) colgar(); });
  window.addEventListener("pagehide", function () { if (enLlamada) colgar(); });
  document.addEventListener("visibilitychange", function () { if (enLlamada && !document.hidden && !wake && navigator.wakeLock) navigator.wakeLock.request("screen").then(function (w) { wake = w; }, function () {}); });
})();
