(function () {
  "use strict";
  var C = window.FLOW_CONFIG;
  var KEY = "flow_convs_v1";
  var ETIQ = [["dato_incorrecto", "Dato incorrecto"], ["palabras_raras", "Palabras raras"], ["perdio_el_hilo", "Perdió el hilo"], ["calculo_mal", "Cálculo mal"], ["otro", "Otro"]];
  var $ = function (id) { return document.getElementById(id); };
  var layout = $("layout"), lista = $("lista"), chat = $("chat"), scroll = $("scroll");
  var form = $("form"), texto = $("texto"), enviar = $("enviar"), contador = $("contador"), estado = $("estado");
  var buscar = $("buscar"), buscaOn = false, transpOn = false, filtro = "";

  var ICON_SEND = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
  var ICON_STOP = '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2.5"/></svg>';
  var ICON_COPY = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 012-2h10"/></svg>';
  var ICON_OK = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg>';
  var ICON_DEL = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/></svg>';
  var ICON_EDIT = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4 12.5-12.5z"/></svg>';
  var ICON_UP = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7 11v9H4v-9h3zM7 11l4-8c1.5 0 2.5 1 2.5 2.500V9H19a2 2 0 012 2.300l-1.200 7A2 2 0 0117.800 20H7"/></svg>';
  var ICON_DOWN = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transform:rotate(180deg)"><path d="M7 11v9H4v-9h3zM7 11l4-8c1.5 0 2.5 1 2.5 2.500V9H19a2 2 0 012 2.300l-1.200 7A2 2 0 0117.800 20H7"/></svg>';

  try { buscaOn = localStorage.getItem("flow_buscar") === "1"; transpOn = localStorage.getItem("flow_transparente") === "1"; } catch (e) {}

  var convs = [];       // [{id, titulo, history, mensajes, t, ctx}]
  var actualId = null;
  var ocupado = false, abortar = null, cancelarEfecto = null, abortarPorTiempo = false;
  var estadoApi = {};   // id de modelo -> {ok, restantes, info}
  var modId = null, esfId = null;
  function listaModelos() { return (C.modelos && C.modelos.length) ? C.modelos : [{ id: "v23", nombre: "FlowNet XT v2.3", etiqueta: "v2.3", detalle: "", apiUrl: C.apiUrl, apiKey: C.apiKey }]; }
  function modPorId(id) { return listaModelos().filter(function (m) { return m.id === id; })[0] || null; }
  function modActual() { return modPorId(modId) || modPorId(C.modeloPorDefecto) || listaModelos()[0]; }
  function listaEsfuerzos() { return (C.esfuerzos && C.esfuerzos.length) ? C.esfuerzos : [{ id: "alto", nombre: "Alto", tokens: 256 }]; }
  function esfActual() {
    var l = listaEsfuerzos();
    if (esInvitado()) return esfMinimo();      // el invitado siempre va en el esfuerzo más bajo (el servidor también lo impone)
    return l.filter(function (e) { return e.id === esfId; })[0] || l.filter(function (e) { return e.id === C.esfuerzoPorDefecto; })[0] || l[l.length - 1];
  }
  /* ---------- sesión de Google (una por servidor de API) y modo invitado ---------- */
  var SES = "flow_sesiones";
  function leerSesiones() {
    try { var o = JSON.parse(localStorage.getItem(SES) || "{}"); return (o && typeof o === "object") ? o : {}; } catch (e) { return {}; }
  }
  function sesionDe(mod) {
    var s = leerSesiones()[mod.apiUrl];
    return (s && typeof s.token === "string" && /^fs1\.[A-Za-z0-9_.-]{10,600}$/.test(s.token) && typeof s.nombre === "string" && s.exp * 1000 > Date.now()) ? s : null;
  }
  function fijarSesion(mod, s) {
    var o = leerSesiones(); if (s) o[mod.apiUrl] = s; else delete o[mod.apiUrl];
    try { localStorage.setItem(SES, JSON.stringify(o)); } catch (e) {}
  }
  function esPi(mod) { return !!mod && mod.tipo === "flowpi"; }   // servidor propio: la API de la Raspberry Pi (/v1/chat, clave Bearer)
  function cabeceras(mod, json) {
    var h = {}; if (json) h["Content-Type"] = "application/json";
    if (esPi(mod)) { if (mod.apiKey) h["Authorization"] = "Bearer " + mod.apiKey; return h; }
    var s = sesionDe(mod);
    if (mod.apiKey) h["X-API-Key"] = mod.apiKey; else if (s) h["Authorization"] = "Bearer " + s.token;
    return h;
  }
  function esInvitado() { var m = modActual(); return !esPi(m) && !m.apiKey && !sesionDe(m); }
  function esfMinimo() { return listaEsfuerzos().slice().sort(function (a, b) { return a.tokens - b.tokens; })[0]; }
  function hora(ms) { return new Date(ms).toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit" }); }
  function mayus(t) { return t ? t.charAt(0).toUpperCase() + t.slice(1) : t; }
  function anotarCuota(e, d) {
    if (!d || typeof d !== "object") return;
    if (typeof d.restantes === "number") e.restantes = d.restantes;
    if (typeof d.modo === "string") e.modo = d.modo;
    if (typeof d.persona === "string") e.persona = d.persona.slice(0, 60);
    if (typeof d.login_google === "boolean") e.loginGoogle = d.login_google;
    if (typeof d.limite_invitado === "number") e.limInv = d.limite_invitado;
    if (typeof d.ventana_min === "number") e.ventana = d.ventana_min;
    e.hasta = (d.restantes === 0 && typeof d.reintentar_en === "number") ? Date.now() + d.reintentar_en * 1000 : null;
  }
  function est() { var id = modActual().id; return estadoApi[id] || (estadoApi[id] = { ok: null, restantes: null, info: null }); }

  function apiUrl(p, mod) { return (mod || modActual()).apiUrl.replace(/\/$/, "") + p; }
  function avisar(t) {
    var d = document.createElement("div"); d.className = "toast"; d.setAttribute("role", "status"); d.textContent = t;
    document.body.appendChild(d); setTimeout(function () { d.remove(); }, 3200);
  }

  /* ---------- búsqueda en Wikipedia (solo desde el navegador; Flow NO lee los resultados) ---------- */
  function limpiarConsulta(s) { return s.replace(/[¿?¡!"<>]/g, " ").replace(/\s+/g, " ").trim().slice(0, 200); }
  async function buscarWeb(msg) {
    var B = C.busqueda || {}, ctl = new AbortController(), t = setTimeout(function () { ctl.abort(); }, B.timeoutMs || 8000);
    try {
      var q = limpiarConsulta(msg); if (!q) return [];
      var url = "https://" + (B.idioma || "es") + ".wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=" + encodeURIComponent(q) +
        "&gsrlimit=" + (B.maxResultados || 3) + "&prop=extracts|info&exintro=1&explaintext=1&exsentences=2&inprop=url&format=json&formatversion=2&origin=*";
      var r = await fetch(url, { signal: ctl.signal });
      if (!r.ok) throw new Error("HTTP " + r.status);
      var d = await r.json();
      var pags = (d && d.query && Array.isArray(d.query.pages)) ? d.query.pages : [];
      pags.sort(function (a, b) { return (a.index || 0) - (b.index || 0); });
      return pags.filter(function (p) { return typeof p.title === "string" && urlWikiOk(p.fullurl); })
        .slice(0, B.maxResultados || 3)
        .map(function (p) { return { titulo: p.title.slice(0, 120), extracto: String(p.extract || "").slice(0, 300), url: p.fullurl }; });
    } finally { clearTimeout(t); }
  }
  function urlWikiOk(u) { return typeof u === "string" && u.indexOf("https://" + ((C.busqueda || {}).idioma || "es") + ".wikipedia.org/") === 0; }
  function bloqueFuentes(f) {         // f = {lista:[...]} o {error:"..."}
    var box = document.createElement("div"); box.className = "fuentes";
    var h = document.createElement("h4"); h.textContent = "Resultados de Wikipedia"; box.appendChild(h);
    if (f.error || !f.lista || !f.lista.length) {
      var n = document.createElement("p"); n.className = "nota"; n.textContent = f.error || "No se encontraron resultados."; box.appendChild(n); return box;
    }
    f.lista.forEach(function (x) {
      var a = document.createElement("a"); a.className = "fuente"; a.href = x.url; a.target = "_blank"; a.rel = "noopener noreferrer";
      var d = document.createElement("div"); d.className = "dom"; d.textContent = "es.wikipedia.org";
      var t = document.createElement("div"); t.className = "tit"; t.textContent = x.titulo;
      var e = document.createElement("div"); e.className = "ext"; e.textContent = x.extracto;
      a.appendChild(d); a.appendChild(t); if (x.extracto) a.appendChild(e); box.appendChild(a);
    });
    var nota = document.createElement("p"); nota.className = "nota"; nota.textContent = "Flow no ha leído estos resultados: su respuesta sale solo de sus pesos.";
    box.appendChild(nota); return box;
  }

  /* ---------- almacenamiento y validación (también para importar) ---------- */
  function guardar() { try { localStorage.setItem(KEY, JSON.stringify({ convs: convs, actualId: actualId })); } catch (e) {} }
  function idNuevo() { return "c" + Date.now() + Math.floor(Math.random() * 100000); }
  function txt(v, max) { return typeof v === "string" ? v.slice(0, max) : ""; }
  function num(v) { return typeof v === "number" && isFinite(v) ? v : 0; }
  function limpiarMensaje(m) {
    if (!m || (m.rol !== "user" && m.rol !== "bot") || typeof m.texto !== "string") return null;
    var o = { rol: m.rol, texto: m.texto.slice(0, 5000) };
    if (m.rol === "user") return o;
    if (m.error) o.error = true;
    if (typeof m.id === "string" && /^[A-Za-z0-9]{1,32}$/.test(m.id)) o.id = m.id;
    if (typeof m.raw === "string") o.raw = m.raw.slice(0, 6000);
    if (Array.isArray(m.calls)) o.calls = m.calls.slice(0, 10).map(function (c) { return { kind: txt(c && c.kind, 40), arg: txt(c && c.arg, 200), result: txt(c && c.result, 200) }; });
    if (m.cpu_ms !== undefined) o.cpu_ms = num(m.cpu_ms);
    if (typeof m.mod === "string" && /^[A-Za-z0-9_-]{1,20}$/.test(m.mod)) o.mod = m.mod;
    if (m.trunc) { o.trunc = true; o.maxTok = num(m.maxTok); }
    if (typeof m.ck === "string") o.ck = m.ck.slice(0, 32);
    if (m.ctx && typeof m.ctx === "object") o.ctx = { usados: num(m.ctx.usados), maximo: num(m.ctx.maximo), olvidados: num(m.ctx.olvidados), recortado: !!m.ctx.recortado };
    if (m.fb && (m.fb.valor === "up" || m.fb.valor === "down")) {
      o.fb = { valor: m.fb.valor, etiqueta: ETIQ.some(function (e) { return e[0] === m.fb.etiqueta; }) ? m.fb.etiqueta : null };
    }
    if (m.fuentes && typeof m.fuentes === "object") {
      if (typeof m.fuentes.error === "string") o.fuentes = { error: m.fuentes.error.slice(0, 200) };
      else if (Array.isArray(m.fuentes.lista)) {
        o.fuentes = { lista: m.fuentes.lista.filter(function (x) { return x && typeof x.titulo === "string" && urlWikiOk(x.url); }).slice(0, 5)
          .map(function (x) { return { titulo: x.titulo.slice(0, 120), extracto: txt(x.extracto, 300), url: x.url }; }) };
      }
    }
    return o;
  }
  function limpiarConv(x) {
    if (!x || typeof x !== "object" || !Array.isArray(x.mensajes) || !Array.isArray(x.history)) return null;
    var c = { id: (typeof x.id === "string" && /^[A-Za-z0-9_-]{1,40}$/.test(x.id)) ? x.id : idNuevo(), titulo: txt(x.titulo, 120) || "Chat importado",
              t: num(x.t) || Date.now(), mensajes: [], history: [] };
    x.mensajes.slice(0, 500).forEach(function (m) { var o = limpiarMensaje(m); if (o) c.mensajes.push(o); });
    x.history.slice(-8).forEach(function (h) { if (Array.isArray(h) && h.length === 2 && typeof h[0] === "string" && typeof h[1] === "string") c.history.push([h[0].slice(0, 2000), h[1].slice(0, 2000)]); });
    if (x.ctx && typeof x.ctx === "object") c.ctx = { usados: num(x.ctx.usados), maximo: num(x.ctx.maximo), olvidados: num(x.ctx.olvidados), recortado: !!x.ctx.recortado };
    return c;
  }
  function cargar() {
    try {
      var d = JSON.parse(localStorage.getItem(KEY) || "null");
      if (d && Array.isArray(d.convs)) { convs = d.convs.map(limpiarConv).filter(Boolean); actualId = d.actualId; }
    } catch (e) {}
  }
  function actual() { return convs.filter(function (c) { return c.id === actualId; })[0] || null; }
  function nueva() {
    var c = { id: idNuevo(), titulo: "Nuevo chat", history: [], mensajes: [], t: Date.now() };
    convs.unshift(c); actualId = c.id; return c;
  }

  /* ---------- barra lateral ---------- */
  function esMovil() { return window.matchMedia("(max-width: 800px)").matches; }
  function lateral(abrir) {
    if (esMovil()) { layout.classList.toggle("abierto", abrir); layout.classList.remove("cerrado"); }
    else { layout.classList.toggle("cerrado", !abrir); layout.classList.remove("abierto"); }
  }
  function lateralAbierto() { return esMovil() ? layout.classList.contains("abierto") : !layout.classList.contains("cerrado"); }
  function grupo(t) {
    var dias = Math.floor((new Date().setHours(0, 0, 0, 0) - new Date(t).setHours(0, 0, 0, 0)) / 86400000);
    return dias <= 0 ? "Hoy" : dias === 1 ? "Ayer" : dias <= 7 ? "Últimos 7 días" : "Anteriores";
  }
  function coincide(c, q) {
    if (c.titulo.toLowerCase().indexOf(q) >= 0) return true;
    return c.mensajes.some(function (m) { return m.texto.toLowerCase().indexOf(q) >= 0; });
  }
  function pintarLista() {
    lista.textContent = "";
    var q = filtro.trim().toLowerCase();
    var con = convs.filter(function (c) { return c.mensajes.length && (!q || coincide(c, q)); }).sort(function (a, b) { return b.t - a.t; });
    if (!con.length) {
      var v = document.createElement("div"); v.className = "vacio-lista";
      v.textContent = q ? "Sin resultados." : "Aquí aparecerán tus conversaciones."; lista.appendChild(v); return;
    }
    var ultimo = "";
    con.forEach(function (c) {
      var g = grupo(c.t);
      if (g !== ultimo) { var h = document.createElement("h3"); h.textContent = g; lista.appendChild(h); ultimo = g; }
      var it = document.createElement("div"); it.className = "item" + (c.id === actualId ? " activo" : "");
      var b = document.createElement("button"); b.className = "titulo"; b.type = "button"; b.textContent = c.titulo; b.title = c.titulo;
      b.addEventListener("click", function () { if (ocupado) return; actualId = c.id; guardar(); pintarTodo(); if (esMovil()) lateral(false); });
      var r = document.createElement("button"); r.className = "renombrar"; r.type = "button"; r.innerHTML = ICON_EDIT; r.setAttribute("aria-label", "Renombrar conversación");
      r.addEventListener("click", function () {
        var n = prompt("Nuevo nombre del chat:", c.titulo);
        if (n === null) return; n = n.trim().slice(0, 60); if (!n) return;
        c.titulo = n; guardar(); pintarLista();
      });
      var d = document.createElement("button"); d.className = "borrar"; d.type = "button"; d.innerHTML = ICON_DEL; d.setAttribute("aria-label", "Borrar conversación");
      d.addEventListener("click", function () {
        if (ocupado || !confirm("¿Borrar esta conversación?")) return;
        convs = convs.filter(function (x) { return x.id !== c.id; });
        if (actualId === c.id) actualId = null;
        guardar(); pintarTodo();
      });
      it.appendChild(b); it.appendChild(r); it.appendChild(d); lista.appendChild(it);
    });
  }

  /* ---------- indicador de contexto y estado de la API ---------- */
  function pintarEstado() {
    estado.textContent = "";
    var c = actual();
    if (c && c.ctx && c.ctx.maximo) {
      var pc = Math.min(100, Math.round(100 * c.ctx.usados / c.ctx.maximo));
      var w = document.createElement("span"); w.className = "ctx";
      var barra = document.createElement("span"); barra.className = "barra" + (pc >= 90 ? " lleno" : pc >= 75 ? " alto" : "");
      var i = document.createElement("i"); i.style.width = pc + "%"; barra.appendChild(i);
      var t = document.createElement("span"); t.textContent = "Contexto " + c.ctx.usados + "/" + c.ctx.maximo + " tokens";
      w.appendChild(barra); w.appendChild(t); w.title = "Cuánto de la memoria de trabajo de Flow (512 tokens) ocupa esta conversación. Al llenarse, olvida los turnos más antiguos.";
      estado.appendChild(w);
    }
    var s = document.createElement("span");
    var e = est();
    if (e.ok === false) s.textContent = esPi(modActual()) ? "Raspberry Pi sin conexión" : "API sin conexión";
    else if (esPi(modActual())) s.textContent = e.ok ? (e.listo === false ? "Raspberry Pi · sin modelo cargado" : "Raspberry Pi · en línea") : "";
    else if (esInvitado()) {
      var L = e.limInv || 3;
      if (e.restantes === 0 && e.hasta) s.textContent = "Invitado · sin mensajes hasta las " + hora(e.hasta);
      else if (e.restantes === 0) s.textContent = "Invitado · hoy no quedan mensajes";
      else if (e.restantes !== null) s.textContent = "Invitado · quedan " + e.restantes + " de " + L + " mensajes esta hora";
    }
    else if (e.restantes !== null) s.textContent = (sesionDe(modActual()) ? sesionDe(modActual()).nombre + " · " : "") + (e.restantes === 0 ? "Hoy no quedan respuestas" : "Quedan " + e.restantes + " respuestas hoy");
    if (s.textContent) estado.appendChild(s);
    pintarCuenta();
  }
  function sondear(mod, cb) {
    var ctl = new AbortController(), t = setTimeout(function () { ctl.abort(); }, 6000);
    if (esPi(mod)) {
      fetch(apiUrl("/v1/health", mod), { signal: ctl.signal }).then(function (r) { return r.json(); }).then(function (d) {
        var e = estadoApi[mod.id] || (estadoApi[mod.id] = {}); e.ok = true; e.listo = !!d && d.estado === "listo";
      }).catch(function () { var e = estadoApi[mod.id] || (estadoApi[mod.id] = {}); e.ok = false; }).then(function () { clearTimeout(t); if (cb) cb(); });
      return;
    }
    fetch(apiUrl("/", mod), { headers: cabeceras(mod, false), signal: ctl.signal }).then(function (r) { return r.json().then(function (d) { return { st: r.status, d: d || {} }; }); }).then(function (x) {
      var e = estadoApi[mod.id] || (estadoApi[mod.id] = {}); e.ok = true;
      if (x.st === 401) {                                  // sesión caducada: se vuelve a invitado
        if (sesionDe(mod)) { fijarSesion(mod, null); var cb2 = cb; cb = null; sondear(mod, cb2); }
        return;
      }
      anotarCuota(e, x.d);
    }).catch(function () { var e = estadoApi[mod.id] || (estadoApi[mod.id] = {}); e.ok = false; }).then(function () { clearTimeout(t); if (cb) cb(); });
  }
  function sondearApi() { sondear(modActual(), pintarEstado); }
  function pintarVersion() {
    var mod = modActual(), e = est();
    $("verModelo").textContent = (e.info && e.info.version) || mod.etiqueta || mod.id;
    var lg = $("legalTxt"); if (lg) lg.textContent = "Flow es un modelo pequeño" + (mod.detalle ? " (" + mod.detalle + ")" : "") + " en pruebas y puede cometer errores.";
    document.title = "Flow " + ((e.info && e.info.version) || mod.etiqueta || "");
    $("selModelo").title = mod.nombre + (e.info && e.info.checkpoint ? " · checkpoint " + e.info.checkpoint : "") + " · clic para cambiar de modelo o esfuerzo";
  }

  /* ---------- mensajes ---------- */
  function cercaDelFinal() { return scroll.scrollHeight - scroll.scrollTop - scroll.clientHeight < 120; }
  function alFinal() { scroll.scrollTop = scroll.scrollHeight; }

  function filaUsuario(t) {
    var f = document.createElement("div"); f.className = "fila-msg user";
    var c = document.createElement("div"); c.className = "cuerpo"; c.textContent = t; f.appendChild(c); return f;
  }
  function logoEstatico() { var i = document.createElement("img"); i.className = "estatico"; i.src = "img/logo.png"; i.alt = ""; i.width = 30; i.height = 30; return i; }
  function filaBot(textoMsg, error) {
    var f = document.createElement("div"); f.className = "fila-msg bot" + (error ? " error" : "");
    var a = document.createElement("div"); a.className = "avatar"; a.setAttribute("aria-hidden", "true"); a.appendChild(logoEstatico());
    var col = document.createElement("div"); col.className = "col";
    var c = document.createElement("div"); c.className = "cuerpo";
    if (textoMsg !== null) c.textContent = textoMsg;
    col.appendChild(c); f.appendChild(a); f.appendChild(col);
    return { fila: f, cuerpo: c, col: col, avatar: a };
  }
  function florAnimada() {            // el logo en capas: al añadir .pensando los pétalos se cierran y se abren
    var f = document.createElement("span"); f.className = "flor";
    for (var k = 0; k < 5; k++) { var p = document.createElement("img"); p.className = "pet"; p.src = "img/flor/p" + k + ".png"; p.alt = ""; p.style.setProperty("--i", k); f.appendChild(p); }
    var c = document.createElement("img"); c.className = "centro"; c.src = "img/flor/centro.png"; c.alt = ""; f.appendChild(c);
    return f;
  }
  function pensar(avatar) { avatar.textContent = ""; var f = florAnimada(); avatar.appendChild(f); requestAnimationFrame(function () { f.classList.add("pensando"); }); }
  function dejarDePensar(avatar) {    // termina el ciclo en curso (flor abierta) antes de volver al logo fijo
    var f = avatar.querySelector(".flor"); if (!f) return;
    var hecho = false, fin = function () { if (hecho) return; hecho = true; avatar.textContent = ""; avatar.appendChild(logoEstatico()); };
    var p = f.querySelector(".pet"); if (p) p.addEventListener("animationiteration", fin, { once: true });
    setTimeout(fin, 2100);
  }

  async function enviarValoracion(c, m, valor, etiqueta) {
    var mod = modPorId(m.mod) || modActual();
    var cuerpo = { id: m.id, valor: valor };
    if (mod.modelo) cuerpo.modelo = mod.modelo;
    if (etiqueta) cuerpo.etiqueta = etiqueta;
    if (C.valoracionesConTexto) {
      var i = c.mensajes.indexOf(m); cuerpo.respuesta = m.texto;
      if (i > 0 && c.mensajes[i - 1].rol === "user") cuerpo.mensaje = c.mensajes[i - 1].texto;
    }
    var r = await fetch(apiUrl("/feedback", mod), { method: "POST", headers: cabeceras(mod, true), body: JSON.stringify(cuerpo) });
    if (!r.ok) throw new Error("HTTP " + r.status);
  }
  function accionesBot(col, m, c) {
    var ac = document.createElement("div"); ac.className = "acciones";
    var cp = document.createElement("button"); cp.type = "button"; cp.innerHTML = ICON_COPY; cp.setAttribute("aria-label", "Copiar respuesta"); cp.title = "Copiar";
    cp.addEventListener("click", function () {
      var ok = function () { cp.innerHTML = ICON_OK; setTimeout(function () { cp.innerHTML = ICON_COPY; }, 1500); };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(m.texto).then(ok, function () {});
    });
    ac.appendChild(cp);
    var nota = document.createElement("div"); nota.className = "fb-nota";
    var etq = document.createElement("div"); etq.className = "etiquetas"; etq.hidden = true;
    if (m.id && !m.error) {
      var up = document.createElement("button"), down = document.createElement("button");
      up.type = down.type = "button"; up.innerHTML = ICON_UP; down.innerHTML = ICON_DOWN;
      up.setAttribute("aria-label", "Buena respuesta"); down.setAttribute("aria-label", "Mala respuesta"); up.title = "Buena respuesta"; down.title = "Mala respuesta";
      var marcar = function () {
        up.classList.toggle("votado", !!m.fb && m.fb.valor === "up"); down.classList.toggle("votado", !!m.fb && m.fb.valor === "down");
        up.setAttribute("aria-pressed", String(!!m.fb && m.fb.valor === "up")); down.setAttribute("aria-pressed", String(!!m.fb && m.fb.valor === "down"));
        if (m.fb) { var e = ETIQ.filter(function (x) { return x[0] === m.fb.etiqueta; })[0]; nota.textContent = "Gracias por tu valoración" + (e ? " (" + e[1] + ")" : "") + "."; }
      };
      var enviarFb = async function (valor, etiqueta) {
        try { await enviarValoracion(c, m, valor, etiqueta); m.fb = { valor: valor, etiqueta: etiqueta || null }; guardar(); etq.hidden = true; marcar(); }
        catch (e) { nota.textContent = "No se pudo enviar la valoración."; }
      };
      up.addEventListener("click", function () { if (m.fb) return; etq.hidden = true; enviarFb("up", null); });
      down.addEventListener("click", function () {
        if (m.fb) return;
        if (!etq.hidden) { etq.hidden = true; return; }
        etq.textContent = "";
        ETIQ.concat([[null, "Sin etiqueta"]]).forEach(function (e) {
          var b = document.createElement("button"); b.type = "button"; b.className = "chip"; b.textContent = e[1];
          b.addEventListener("click", function () { enviarFb("down", e[0]); });
          etq.appendChild(b);
        });
        etq.hidden = false;
      });
      ac.appendChild(up); ac.appendChild(down); marcar();
    }
    if (m.mod) { var sl = document.createElement("span"); sl.className = "sello"; var mm = modPorId(m.mod); sl.textContent = mm ? (mm.etiqueta || mm.id) : m.mod; sl.title = "Modelo que generó esta respuesta"; ac.appendChild(sl); }
    col.appendChild(ac); col.appendChild(etq); col.appendChild(nota);
  }
  function detalleTecnico(m) {
    if (typeof m.raw !== "string") return null;
    var d = document.createElement("details"); d.className = "detalle";
    var s = document.createElement("summary"); s.textContent = "Detalle técnico"; d.appendChild(s);
    var h1 = document.createElement("h5"); h1.textContent = "Texto bruto del modelo"; var p1 = document.createElement("pre"); p1.textContent = m.raw || "(vacío)";
    var h2 = document.createElement("h5"); h2.textContent = "Llamadas a herramientas"; d.appendChild(h1); d.appendChild(p1); d.appendChild(h2);
    if (m.calls && m.calls.length) {
      var ul = document.createElement("ul");
      m.calls.forEach(function (c) { var li = document.createElement("li"); li.textContent = c.kind + "(" + c.arg + ") → " + c.result; ul.appendChild(li); });
      d.appendChild(ul);
    } else { var n = document.createElement("div"); n.textContent = "Ninguna: la respuesta salió solo del modelo."; d.appendChild(n); }
    var meta = []; if (m.mod) meta.push("modelo " + m.mod); if (typeof m.cpu_ms === "number") meta.push("CPU " + m.cpu_ms + " ms"); if (m.ck) meta.push("checkpoint " + m.ck);
    if (meta.length) { var mp = document.createElement("div"); mp.style.marginTop = "6px"; mp.textContent = meta.join(" · "); d.appendChild(mp); }
    return d;
  }
  function adornosBot(col, m, c) {
    if (!m.error) accionesBot(col, m, c);
    if (m.ctx && (m.ctx.olvidados > 0 || m.ctx.recortado)) {
      var a = document.createElement("div"); a.className = "aviso-ctx";
      a.textContent = m.ctx.recortado ? "Contexto lleno: el último intercambio no cabe y se ha olvidado; Flow puede perder el hilo."
        : "Contexto lleno: Flow ha olvidado " + m.ctx.olvidados + " turno(s) antiguo(s) de esta conversación.";
      col.appendChild(a);
    }
    if (m.trunc) {
      var tr = document.createElement("div"); tr.className = "aviso-ctx";
      tr.textContent = "Respuesta cortada por el límite de esfuerzo (" + m.maxTok + " tokens). Sube el esfuerzo en el menú de arriba para dejarle más espacio."; col.appendChild(tr);
    }
    if (m.fuentes) col.appendChild(bloqueFuentes(m.fuentes));
    var d = detalleTecnico(m); if (d) col.appendChild(d);
  }
  function pintarChat() {
    chat.textContent = "";
    var c = actual();
    if (!c || !c.mensajes.length) {
      var w = document.createElement("div"); w.className = "bienvenida";
      var lg = document.createElement("img"); lg.className = "logo-grande"; lg.src = "img/logo.png"; lg.alt = "Logotipo de Flow"; w.appendChild(lg);
      var h = document.createElement("h2"); h.textContent = "¿En qué puedo ayudarte?"; w.appendChild(h);
      var chips = document.createElement("div"); chips.className = "chips";
      (C.sugerencias || []).forEach(function (s) {
        var b = document.createElement("button"); b.type = "button"; b.className = "chip"; b.textContent = s;
        b.addEventListener("click", function () { enviarMensaje(s); });
        chips.appendChild(b);
      });
      w.appendChild(chips); chat.appendChild(w); return;
    }
    c.mensajes.forEach(function (m) {
      if (m.rol === "user") chat.appendChild(filaUsuario(m.texto));
      else { var b = filaBot(m.texto, m.error); adornosBot(b.col, m, c); chat.appendChild(b.fila); }
    });
    alFinal();
  }
  function pintarTodo() { pintarLista(); pintarChat(); pintarEstado(); estadoBoton(); }

  /* ---------- envío ---------- */
  function estadoBoton() {
    if (ocupado) { enviar.innerHTML = ICON_STOP; enviar.disabled = false; enviar.setAttribute("aria-label", "Detener"); }
    else { enviar.innerHTML = ICON_SEND; enviar.disabled = !texto.value.trim(); enviar.setAttribute("aria-label", "Enviar mensaje"); }
  }
  function mensajeError(status, data, mod) {
    if (esPi(mod)) {
      var tp = data && data.error && typeof data.error === "object" ? txt(data.error.mensaje, 200) : txt(data && data.error, 200);
      if (status === 401) return "La clave de la API no es válida o falta. Avisa a quien administra la web.";
      if (status === 429) return mayus(tp) || "Demasiadas peticiones seguidas. Espera unos segundos.";
      if (status === 503) return mayus(tp) || "La Raspberry Pi está ocupada. Inténtalo en unos segundos.";
      return "Error del servidor (" + status + ")." + (tp ? " " + mayus(tp) : "");
    }
    if (status === 401) return "Tu sesión ha caducado o no es válida. Inicia sesión de nuevo con Google.";
    if (status === 403) return mayus(txt(data && data.error, 200)) || "Acceso denegado.";
    if (status === 429) {
      var m429 = mayus(txt(data && data.error, 200)) || "Límite de respuestas alcanzado";
      if (data && typeof data.reintentar_en === "number") return m429 + ". Podrás volver a escribir a las " + hora(Date.now() + data.reintentar_en * 1000) + ", o iniciar sesión con Google para tener más respuestas.";
      return m429 + ". Vuelve mañana.";
    }
    if (status === 400) return "Petición no válida: " + ((data && data.error) || "revisa el mensaje.");
    if (status === 413) return "El mensaje es demasiado grande.";
    return "Error del servidor (" + status + ")." + (data && data.error ? " " + data.error : "");
  }
  async function preguntar(msg, history, mod, esf) {
    var ctl = new AbortController(); abortar = function () { ctl.abort(); };
    var t = setTimeout(function () { abortarPorTiempo = true; ctl.abort(); }, C.timeoutMs);
    try {
      if (esPi(mod)) return await preguntarPi(msg, history, mod, esf, ctl);
      var cuerpo = { message: msg, history: history.slice(-C.maxHistory), max_tokens: esf.tokens };
      if (mod.modelo) cuerpo.modelo = mod.modelo;
      var r = await fetch(apiUrl("/chat", mod), {
        method: "POST",
        headers: cabeceras(mod, true),
        body: JSON.stringify(cuerpo),
        signal: ctl.signal
      });
      var data = null; try { data = await r.json(); } catch (e) {}
      if (!r.ok) throw { status: r.status, data: data };
      return data;
    } finally { clearTimeout(t); abortar = null; }
  }
  async function preguntarPi(msg, history, mod, esf, ctl) {   // la API de la Pi no guarda nada: se le manda el historial en cada petición
    var msgs = [];
    history.slice(-C.maxHistory).forEach(function (h) { msgs.push({ role: "user", content: h[0] }); msgs.push({ role: "assistant", content: h[1] }); });
    msgs.push({ role: "user", content: msg });
    var r = await fetch(apiUrl("/v1/chat", mod), { method: "POST", headers: cabeceras(mod, true), signal: ctl.signal,
      body: JSON.stringify({ messages: msgs, max_tokens: esf.tokens }) });
    var data = null; try { data = await r.json(); } catch (e) {}
    if (!r.ok) throw { status: r.status, data: data };
    var rsp = data && typeof data.respuesta === "string" ? data.respuesta : "";
    var h2 = history.concat([[msg.slice(0, 2000), rsp.slice(0, 2000)]]).slice(-C.maxHistory);
    return { reply: rsp, history: h2, truncada: !!data && (data.parada === "limit" || data.parada === "context"), max_tokens: esf.tokens,
             modelo: { version: mod.etiqueta || undefined, checkpoint: txt(data && data.modelo, 32) } };
  }
  function escribir(cuerpo, t) {   // efecto cosmético: la respuesta ya está completa
    return new Promise(function (resolve) {
      var reducir = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      if (!C.efectoEscritura || reducir) { cuerpo.textContent = t; return resolve(); }
      var partes = t.split(/(\s+)/), i = 0, id;
      cancelarEfecto = function () { clearInterval(id); cuerpo.textContent = t; cancelarEfecto = null; resolve(); };
      id = setInterval(function () {
        var pegado = cercaDelFinal();
        cuerpo.textContent += partes[i++] || "";
        if (pegado) alFinal();
        if (i >= partes.length) { clearInterval(id); cancelarEfecto = null; resolve(); }
      }, 22);
    });
  }

  async function enviarMensaje(msg, op) {     // op = { llamada: true, alResponder(texto, error) } (lo usa la llamada de voz)
    op = op || {};
    if (ocupado) return null;
    msg = msg.trim(); if (!msg) return null;
    if (op.llamada) msg = msg.slice(0, C.maxChars);
    var c = actual() || nueva();
    if (!c.mensajes.length) c.titulo = msg.length > 40 ? msg.slice(0, 40) + "…" : msg;
    ocupado = true; estadoBoton();
    c.mensajes.push({ rol: "user", texto: msg }); c.t = Date.now(); guardar();
    pintarLista(); pintarChat();
    var b = filaBot(null); var p = document.createElement("div"); p.className = "puntos"; p.innerHTML = "<i></i><i></i><i></i>";
    b.cuerpo.appendChild(p); chat.appendChild(b.fila); pensar(b.avatar); alFinal();
    var resultado = null, detenido = false, fuentes = null, d = null, mod = modActual(), esf = esfActual();
    var busqueda = (buscaOn && !esInvitado()) ? buscarWeb(msg).then(function (l) { return { lista: l }; }, function () { return { error: "La búsqueda en Wikipedia ha fallado (sin conexión o bloqueada)." }; }) : null;
    try {
      d = await preguntar(msg, c.history, mod, esf);
      if (busqueda) fuentes = await busqueda;
      resultado = { txt: d.reply && d.reply.trim() ? d.reply : (d.truncada ? "(sin respuesta: el límite de tokens se agotó antes de empezar a responder)" : "(sin respuesta)"), history: Array.isArray(d.history) ? d.history : c.history };
    } catch (e) {
      if (e && e.name === "AbortError" && !abortarPorTiempo) detenido = true;
      else {
        var tx = (e && e.name === "AbortError") ? "La API tardó demasiado en responder. Inténtalo de nuevo."
          : (e && e.status) ? mensajeError(e.status, e.data, mod)
          : "No se pudo contactar con la API (¿sin conexión, o la web de la API está apagada?).";
        resultado = { txt: tx, error: true };
        var ee = estadoApi[mod.id] || (estadoApi[mod.id] = {});
        if (e && e.status === 429) { ee.restantes = 0; ee.hasta = (e.data && typeof e.data.reintentar_en === "number") ? Date.now() + e.data.reintentar_en * 1000 : null; }
        if (e && e.status === 401 && sesionDe(mod)) { fijarSesion(mod, null); avisar("Tu sesión ha caducado."); }
        if (!(e && e.status)) ee.ok = false;
      }
    }
    abortarPorTiempo = false;
    if (op.alResponder && !detenido) { try { op.alResponder(resultado.txt, !!resultado.error); } catch (e) {} }
    dejarDePensar(b.avatar);
    if (detenido) {
      c.mensajes.pop(); b.fila.remove();            // se deshace el mensaje: el servidor no llegó a guardar nada
      if (!op.llamada) { texto.value = msg; ajustar(); }
    } else {
      var m = { rol: "bot", texto: resultado.txt };
      if (resultado.error) m.error = true;
      else {
        var es = estadoApi[mod.id] || (estadoApi[mod.id] = {}); es.ok = true;
        anotarCuota(es, d);
        if (d.modelo) { es.info = d.modelo; pintarVersion(); m.ck = txt(d.modelo.checkpoint, 32); }
        m.mod = mod.id;
        if (d.truncada) { m.trunc = true; m.maxTok = num(d.max_tokens); }
        if (typeof d.id === "string" && /^[A-Za-z0-9]{1,32}$/.test(d.id)) m.id = d.id;
        if (typeof d.raw === "string") m.raw = d.raw.slice(0, 6000);
        if (Array.isArray(d.calls)) m.calls = d.calls.slice(0, 10).map(function (x) { return { kind: txt(x && x.kind, 40), arg: txt(x && x.arg, 200), result: txt(x && x.result, 200) }; });
        if (typeof d.cpu_ms === "number") m.cpu_ms = d.cpu_ms;
        if (d.contexto && typeof d.contexto === "object") {
          m.ctx = { usados: num(d.contexto.usados), maximo: num(d.contexto.maximo), olvidados: num(d.contexto.olvidados), recortado: !!d.contexto.recortado };
          c.ctx = m.ctx;
        }
        if (fuentes) m.fuentes = fuentes;
      }
      b.cuerpo.textContent = "";
      if (resultado.error) { b.fila.classList.add("error"); b.cuerpo.textContent = resultado.txt; }
      else { await escribir(b.cuerpo, resultado.txt); adornosBot(b.col, m, c); }
      c.mensajes.push(m);
      if (resultado.history) c.history = resultado.history;
      c.t = Date.now();
    }
    guardar(); ocupado = false; pintarTodo(); if (!detenido) alFinal(); if (!op.llamada) texto.focus();
    return detenido ? null : { texto: resultado.txt, error: !!resultado.error };
  }

  /* ---------- entrada ---------- */
  function ajustar() {
    texto.style.height = "auto";
    texto.style.height = Math.min(texto.scrollHeight, 200) + "px";
    contador.textContent = texto.value.length + "/" + C.maxChars;
    if (!ocupado) enviar.disabled = !texto.value.trim();
  }
  form.addEventListener("submit", function (ev) {
    ev.preventDefault();
    if (ocupado) { if (cancelarEfecto) cancelarEfecto(); else if (abortar) abortar(); return; }
    var m = texto.value; if (!m.trim()) return;
    texto.value = ""; ajustar(); enviarMensaje(m);
  });
  texto.addEventListener("keydown", function (ev) {
    if (ev.key === "Enter" && !ev.shiftKey && !ev.isComposing) { ev.preventDefault(); if (!ocupado) form.requestSubmit(); }
  });
  texto.addEventListener("input", ajustar);

  function nuevoChat() {
    if (ocupado) return;
    var c = actual();
    if (c && !c.mensajes.length) { texto.focus(); if (esMovil()) lateral(false); return; }
    nueva(); guardar(); pintarTodo(); texto.focus(); if (esMovil()) lateral(false);
  }
  function pintarBuscar() {
    var inv = esInvitado();
    buscar.setAttribute("aria-pressed", (buscaOn && !inv) ? "true" : "false");
    buscar.setAttribute("aria-disabled", inv ? "true" : "false");
    buscar.title = inv ? "Inicia sesión con Google para buscar en la web" : "Buscar en Wikipedia antes de responder";
  }
  buscar.addEventListener("click", function () {
    if (esInvitado()) { avisar("La búsqueda en la web está disponible al iniciar sesión con Google."); abrirCuenta(); return; }
    buscaOn = !buscaOn; pintarBuscar();
    try { localStorage.setItem("flow_buscar", buscaOn ? "1" : "0"); } catch (e) {}
    texto.focus();
  });
  function pintarTransp() { document.body.classList.toggle("transparente", transpOn); $("transp").setAttribute("aria-pressed", transpOn ? "true" : "false"); }
  $("transp").addEventListener("click", function () {
    transpOn = !transpOn; pintarTransp();
    try { localStorage.setItem("flow_transparente", transpOn ? "1" : "0"); } catch (e) {}
  });
  /* ---------- cuenta: iniciar / cerrar sesión con Google ---------- */
  var gCargado = null, gIniciado = false, acceso = $("acceso");
  function pintarCuenta() {
    var s = sesionDe(modActual()), cab = $("cuentaCab"), fila = $("cuenta");
    cab.hidden = fila.hidden = esPi(modActual());      // el servidor de la Pi no tiene cuentas de Google: solo clave de API
    cab.textContent = "";
    if (s) { var av = document.createElement("span"); av.className = "avatar"; av.textContent = (s.nombre.trim().charAt(0) || "?").toUpperCase(); cab.appendChild(av); cab.title = "Cuenta de " + s.nombre; cab.classList.add("con-sesion"); }
    else { cab.textContent = "Iniciar sesión"; cab.title = "Iniciar sesión con Google"; cab.classList.remove("con-sesion"); }
    fila.querySelector("span").textContent = s ? "Cerrar sesión (" + s.nombre + ")" : "Iniciar sesión con Google";
    pintarBuscar();
  }
  function cargarGoogle() {
    if (gCargado) return gCargado;
    gCargado = new Promise(function (ok, ko) {
      var sc = document.createElement("script"); sc.src = "https://accounts.google.com/gsi/client"; sc.async = true;
      sc.onload = function () { ok(); }; sc.onerror = function () { gCargado = null; ko(new Error("no se pudo cargar Google")); };
      document.head.appendChild(sc);
    });
    return gCargado;
  }
  function cerrarCuenta() { acceso.hidden = true; $("gBoton").textContent = ""; }
  async function alCredencial(resp) {
    var mod = modActual(), err = $("accesoError"); err.textContent = "Comprobando…";
    try {
      var r = await fetch(apiUrl("/auth/google", mod), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ credential: resp.credential }) });
      var d = null; try { d = await r.json(); } catch (e) {}
      if (!r.ok) { err.textContent = (d && d.error) ? mayus(txt(d.error, 200)) + "." : "No se pudo iniciar sesión (" + r.status + ")."; return; }
      if (!d || typeof d.sesion !== "string" || typeof d.expira !== "number") { err.textContent = "Respuesta inesperada del servidor."; return; }
      fijarSesion(mod, { token: d.sesion, nombre: txt(d.nombre, 60) || "Usuario", exp: d.expira });
      var e0 = estadoApi[mod.id] || (estadoApi[mod.id] = {}); anotarCuota(e0, d);
      cerrarCuenta(); avisar("Sesión iniciada. ¡Hola, " + (txt(d.nombre, 60) || "Usuario") + "!");
      pintarEstado(); sondear(mod, pintarEstado);
    } catch (e) { err.textContent = "No se pudo contactar con la API."; }
  }
  function abrirCuenta() {
    var mod = modActual(), s = sesionDe(mod), e = est();
    $("accesoError").textContent = ""; $("gBoton").textContent = "";
    $("accesoSalir").hidden = !s;
    if (s) {
      $("accesoTit").textContent = "Sesión iniciada";
      $("accesoMsg").textContent = s.nombre + (typeof e.restantes === "number" ? " · quedan " + e.restantes + " respuestas hoy" : "") + ". Con tu cuenta puedes elegir el esfuerzo y buscar en la web.";
    } else {
      $("accesoTit").textContent = "Inicia sesión";
      $("accesoMsg").textContent = "Como invitado tienes " + (e.limInv || 3) + " mensajes por hora, esfuerzo bajo y sin búsqueda en la web. Con tu cuenta de Google tienes más respuestas al día, eliges el esfuerzo y puedes buscar en Wikipedia.";
      if (!C.googleClientId) $("accesoError").textContent = "El inicio de sesión aún no está configurado (falta googleClientId en js/config.js).";
      else if (e.loginGoogle === false) $("accesoError").textContent = "Este servidor todavía no tiene activado el inicio de sesión con Google.";
      else {
        $("accesoError").textContent = "Cargando Google…";
        cargarGoogle().then(function () {
          if (acceso.hidden || sesionDe(modActual())) return;
          if (!gIniciado) { window.google.accounts.id.initialize({ client_id: C.googleClientId, callback: alCredencial, auto_select: false }); gIniciado = true; }
          $("accesoError").textContent = "";
          window.google.accounts.id.renderButton($("gBoton"), { theme: "outline", size: "large", text: "signin_with", shape: "pill", locale: "es", width: 260 });
        }, function () { $("accesoError").textContent = "No se pudo cargar el inicio de sesión de Google (¿sin conexión o bloqueado por una extensión?)."; });
      }
    }
    acceso.hidden = false;
  }
  $("cuentaCab").addEventListener("click", abrirCuenta);
  $("cuenta").addEventListener("click", function () { if (esMovil()) lateral(false); abrirCuenta(); });
  $("accesoCerrar").addEventListener("click", cerrarCuenta);
  acceso.addEventListener("click", function (ev) { if (ev.target === acceso) cerrarCuenta(); });
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && !acceso.hidden) cerrarCuenta(); });
  $("accesoSalir").addEventListener("click", function () {
    var mod = modActual(); fijarSesion(mod, null); try { if (window.google && window.google.accounts) window.google.accounts.id.disableAutoSelect(); } catch (e) {}
    cerrarCuenta(); avisar("Sesión cerrada."); pintarEstado(); sondear(mod, pintarEstado);
  });
  $("buscarChats").addEventListener("input", function (ev) { filtro = ev.target.value; pintarLista(); });
  $("nuevo").addEventListener("click", nuevoChat);
  $("nuevoMovil").addEventListener("click", nuevoChat);
  $("abrirLateral").addEventListener("click", function () { lateral(!lateralAbierto()); });
  $("cerrarLateral").addEventListener("click", function () { lateral(false); });
  $("velo").addEventListener("click", function () { lateral(false); });

  /* ---------- exportar / importar ---------- */
  function descargar(nombre, contenido, tipo) {
    var url = URL.createObjectURL(new Blob([contenido], { type: tipo }));
    var a = document.createElement("a"); a.href = url; a.download = nombre; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }
  function hoy() { return new Date().toISOString().slice(0, 10); }
  $("expTodo").addEventListener("click", function () {
    var con = convs.filter(function (c) { return c.mensajes.length; });
    if (!con.length) { avisar("No hay conversaciones que exportar."); return; }
    descargar("flow-chats-" + hoy() + ".json", JSON.stringify({ formato: "flow-chats", version: 1, exportado: new Date().toISOString(), convs: con }, null, 2), "application/json");
  });
  $("expChat").addEventListener("click", function () {
    var c = actual(); if (!c || !c.mensajes.length) { avisar("Esta conversación está vacía."); return; }
    var md = "# " + c.titulo + "\n\n" + c.mensajes.map(function (m) { return (m.rol === "user" ? "**Tú:** " : "**Flow:** ") + m.texto; }).join("\n\n") + "\n";
    descargar("flow-chat-" + hoy() + ".md", md, "text/markdown");
  });
  $("importar").addEventListener("click", function () { if (ocupado) { avisar("Espera a que Flow termine de responder."); return; } $("archivo").click(); });
  $("archivo").addEventListener("change", async function (ev) {
    var f = ev.target.files[0]; ev.target.value = ""; if (!f) return;
    if (ocupado) { avisar("Espera a que Flow termine de responder."); return; }
    if (f.size > 5000000) { avisar("El archivo es demasiado grande."); return; }
    var d; try { d = JSON.parse(await f.text()); } catch (e) { avisar("El archivo no es un JSON válido."); return; }
    if (!d || d.formato !== "flow-chats" || !Array.isArray(d.convs)) { avisar("No es una exportación de Flow."); return; }
    var n = 0;
    d.convs.slice(0, 200).forEach(function (x) {
      var c = limpiarConv(x); if (!c || !c.mensajes.length || convs.length >= 300) return;
      if (convs.some(function (y) { return y.id === c.id; })) c.id = idNuevo();
      convs.push(c); n++;
    });
    guardar(); pintarTodo(); avisar(n ? "Importadas " + n + " conversación(es)." : "No se importó ninguna conversación.");
  });

  /* ---------- menú de modelo y esfuerzo ---------- */
  var menu = $("menuModelo"), selModelo = $("selModelo");
  function cerrarMenu() { menu.hidden = true; selModelo.setAttribute("aria-expanded", "false"); }
  function titulo(t) { var h = document.createElement("div"); h.className = "menu-tit"; h.textContent = t; return h; }
  function construirMenu() {
    menu.textContent = "";
    menu.appendChild(titulo("Modelo"));
    listaModelos().forEach(function (mod) {
      var b = document.createElement("button"); b.type = "button"; b.className = "opcion"; b.setAttribute("role", "menuitemradio");
      var activo = mod.id === modActual().id; b.setAttribute("aria-checked", String(activo));
      var t1 = document.createElement("span"); t1.className = "o-nom"; t1.textContent = mod.nombre;
      var t2 = document.createElement("span"); t2.className = "o-det"; t2.textContent = mod.detalle || "";
      var t3 = document.createElement("span"); t3.className = "o-est"; var e = estadoApi[mod.id] || {};
      t3.textContent = e.ok === true ? "● en línea" + (typeof e.restantes === "number" ? " · quedan " + e.restantes + " hoy" : "") : e.ok === false ? "○ sin conexión" : "… comprobando";
      var tx = document.createElement("span"); tx.className = "o-txt"; tx.appendChild(t1); if (mod.detalle) tx.appendChild(t2); tx.appendChild(t3);
      var ck = document.createElement("span"); ck.className = "o-ck"; ck.textContent = activo ? "✓" : "";
      b.appendChild(tx); b.appendChild(ck);
      b.addEventListener("click", function () {
        if (ocupado) { avisar("Espera a que Flow termine de responder."); return; }
        if (mod.id !== modActual().id) {
          modId = mod.id; try { localStorage.setItem("flow_modelo", modId); } catch (er) {}
          pintarVersion(); pintarEstado(); sondearApi(); avisar("Modelo: " + mod.nombre + ". La conversación sigue con el mismo historial.");
        }
        construirMenu();
      });
      menu.appendChild(b);
    });
    menu.appendChild(titulo("Esfuerzo"));
    listaEsfuerzos().forEach(function (esf) {
      var b = document.createElement("button"); b.type = "button"; b.className = "opcion corta"; b.setAttribute("role", "menuitemradio");
      var activo = esf.id === esfActual().id; b.setAttribute("aria-checked", String(activo));
      if (esInvitado() && !activo) { b.classList.add("bloqueado"); b.setAttribute("aria-disabled", "true"); }
      var tx = document.createElement("span"); tx.className = "o-txt"; var n = document.createElement("span"); n.className = "o-nom"; n.textContent = esf.nombre + " · " + esf.tokens + " tokens"; tx.appendChild(n);
      var ck = document.createElement("span"); ck.className = "o-ck"; ck.textContent = activo ? "✓" : "";
      b.appendChild(tx); b.appendChild(ck);
      b.addEventListener("click", function () {
        if (esInvitado()) { avisar("Como invitado el esfuerzo es siempre Bajo. Inicia sesión con Google para elegirlo."); return; }
        esfId = esf.id; try { localStorage.setItem("flow_esfuerzo", esfId); } catch (er) {} construirMenu();
      });
      menu.appendChild(b);
    });
    var nota = document.createElement("p"); nota.className = "menu-nota";
    nota.textContent = (esInvitado() ? "Como invitado el esfuerzo es siempre Bajo. " : "") + "El esfuerzo solo limita cuántos tokens puede escribir Flow (incluidas sus llamadas a herramientas). No lo hace más listo: una respuesta larga se corta.";
    menu.appendChild(nota);
  }
  selModelo.addEventListener("click", function (ev) {
    ev.stopPropagation();
    if (!menu.hidden) { cerrarMenu(); return; }
    construirMenu(); menu.hidden = false; selModelo.setAttribute("aria-expanded", "true");
    listaModelos().forEach(function (mod) { sondear(mod, function () { if (!menu.hidden) construirMenu(); pintarEstado(); }); });
  });
  document.addEventListener("click", function (ev) { if (!menu.hidden && !menu.contains(ev.target)) cerrarMenu(); });
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && !menu.hidden) { cerrarMenu(); selModelo.focus(); } });

  /* ---------- tema ---------- */
  var temas = ["auto", "light", "dark"], nombres = { auto: "Tema: automático", light: "Tema: claro", dark: "Tema: oscuro" };
  function temaActual() { try { return localStorage.getItem("flow_theme") || "auto"; } catch (e) { return "auto"; } }
  function aplicarTema(t) {
    if (t === "auto") document.documentElement.removeAttribute("data-theme"); else document.documentElement.dataset.theme = t;
    $("temaTxt").textContent = nombres[t];
  }
  $("tema").addEventListener("click", function () {
    var t = temas[(temas.indexOf(temaActual()) + 1) % 3];
    try { if (t === "auto") localStorage.removeItem("flow_theme"); else localStorage.setItem("flow_theme", t); } catch (e) {}
    aplicarTema(t);
  });

  /* ---------- puente para la llamada de voz (js/llamada.js) ---------- */
  window.FlowApp = {
    enviar: function (msg, alResponder) { return enviarMensaje(msg, { llamada: true, alResponder: alResponder }); },
    cancelar: function () { if (abortar) abortar(); },
    ocupado: function () { return ocupado; },
    maxChars: function () { return C.maxChars; },
    tema: function () { return document.documentElement.dataset.theme || ""; },
    florAnimada: florAnimada,
    avisar: avisar
  };
  /* ---------- inicio ---------- */
  cargar();
  if (!actual()) { var vacia = convs.filter(function (c) { return !c.mensajes.length; })[0]; if (vacia) actualId = vacia.id; else nueva(); }
  if (esMovil()) layout.classList.add("cerrado");
  try { modId = localStorage.getItem("flow_modelo"); esfId = localStorage.getItem("flow_esfuerzo"); } catch (e) {}
  aplicarTema(temaActual()); pintarBuscar(); pintarTransp(); pintarVersion();
  pintarTodo(); ajustar(); sondearApi();
})();
