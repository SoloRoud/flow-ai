// Configuración de la web. Cambia aquí la dirección de la API y el Client ID de Google.
// OJO: este fichero lo descarga cualquiera que abra la web: no pongas aquí ninguna clave secreta.
// Dos tipos de servidor:
//   · tipo "flowpi"  → la API de tu Raspberry Pi (Flow Pi, ruta /v1/chat). Necesita una clave flw_… creada en la pestaña API del panel.
//                      Como la web es pública, esa clave la verá cualquiera: crea una SOLO para la web, con pocas peticiones por minuto, y bórrala si abusan.
//   · sin "tipo"     → el servidor antiguo (PythonAnywhere, ruta /chat) con invitados y sesión de Google.
// Si la web está en GitHub Pages, el panel de la Pi debe permitir ese origen (pestaña API › orígenes permitidos): https://TU_USUARIO.github.io
window.FLOW_CONFIG = {
  // Client ID de Google (solo para el servidor antiguo; la Pi no usa Google). Es público por diseño.
  googleClientId: "",
  apiUrl: "https://roud4000.pythonanywhere.com",
  apiKey: "",           // (modo antiguo, sin uso si "modelos" está definido)
  // Modelos disponibles (menú junto al nombre "Flow"). Cada uno puede tener su propia API,
  // o compartir servidor con otro y distinguirse por "modelo" (id definido en modelos.json del servidor).
  modelos: [
    // Tu Raspberry Pi (por Tailscale Funnel). Cambia apiUrl por la dirección https que te dé «tailscale funnel status» + el puerto de la API, y pon la clave de la web.
    { id: "pi", tipo: "flowpi", nombre: "Flow (Raspberry Pi)", etiqueta: "XT", detalle: "modelo propio en español",
      apiUrl: "https://TU-PI.tu-red.ts.net:8443", apiKey: "flw_PON-AQUI-LA-CLAVE-DE-LA-WEB" }
    // Servidor antiguo (con invitados y Google), por si lo quieres dejar como segunda opción:
    // , { id: "v23", nombre: "FlowNet XT v2.3", etiqueta: "v2.3", detalle: "3,16 M de parámetros", apiUrl: "https://roud4000.pythonanywhere.com", apiKey: "" }
  ],
  modeloPorDefecto: "pi",
  // Esfuerzo = tope de tokens que Flow puede escribir en una respuesta (no lo hace más listo; solo limita la longitud y la CPU).
  esfuerzos: [
    { id: "bajo",  nombre: "Bajo",  tokens: 64 },
    { id: "medio", nombre: "Medio", tokens: 128 },
    { id: "alto",  nombre: "Alto",  tokens: 256 }
  ],
  esfuerzoPorDefecto: "alto",
  // Llamada de voz (botón de las ondas junto al campo de texto). Usa el reconocimiento y la síntesis de voz del navegador: Chrome, Edge o Safari.
  llamada: {
    idioma: "es-ES",                                  // idioma que entiende el micrófono
    saludo: "Hola, soy Flow. Te escucho.",            // se dice al descolgar ("" para no decir nada)
    vozPreferida: "",                                 // texto del nombre de una voz que prefieras, p. ej. "Alvaro|Elvira"; vacío = la más natural que haya
    nivelMic: false                                   // true = la flor reacciona al volumen de tu voz también en el móvil (puede dar problemas en Android)
  },
  maxHistory: 8,        // el servidor admite como máximo 8 pares
  maxChars: 500,        // longitud máxima del mensaje en el servidor
  timeoutMs: 90000,     // la primera respuesta tras un reinicio tarda más (carga el modelo)
  busqueda: {            // botón "Buscar": consulta Wikipedia desde el navegador (sin servidor ni clave)
    idioma: "es",        // es.wikipedia.org
    maxResultados: 3,
    timeoutMs: 8000
  },
  valoracionesConTexto: false, // si es true, al valorar se envía también el mensaje y la respuesta (el servidor solo los guarda si se activa FLOW_GUARDAR_TEXTO=1)
  efectoEscritura: true, // la respuesta llega entera de golpe; esto solo la va mostrando palabra a palabra
  sugerencias: [
    "Hola, Flow. ¿Quién eres?",
    "¿Cuánto es 15 por 12?",
    "Explícame qué es la fotosíntesis",
    "¿Cuál es la capital de Francia?"
  ]
};
