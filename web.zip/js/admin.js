// Modo admin: se activa pulsando A + D + M + I + N + R a la vez (y ninguna tecla más).
// OJO: en una web estática esto NO es seguridad. Cualquiera puede leer este fichero. Lo único que hace es guardar APIs y ajustes en el
// almacenamiento de ESTE navegador (localStorage): no cambia nada para los demás visitantes y no protege ninguna clave.
(function () {
  "use strict";
  var F = window.FlowApp, C = window.FLOW_CONFIG || {};
  if (!F || !F.admin) return;
  var AD = F.admin;
  var CHORD = { KeyA: 1, KeyD: 1, KeyM: 1, KeyI: 1, KeyN: 1, KeyR: 1 };
  var down = {}, instantanea = null;
  var activo = false; try { activo = sessionStorage.getItem("flow_admin_on") === "1"; } catch (e) {}
  var fondo = null, chip = null, editando = null;

  function h(tag, cls, texto) { var e = document.createElement(tag); if (cls) e.className = cls; if (texto !== undefined) e.textContent = texto; return e; }
  function boton(texto, cls, fn) { var b = h("button", cls || "adm-b", texto); b.type = "button"; b.addEventListener("click", fn); return b; }

  /* ---------- combinación de teclas ---------- */
  function campoActivo() { var a = document.activeElement; return a && (a.tagName === "TEXTAREA" || a.tagName === "INPUT") && a.type !== "range" && a.type !== "checkbox" ? a : null; }
  document.addEventListener("keydown", function (ev) {
    if (ev.repeat) return;
    if (!Object.keys(down).length) { var c = campoActivo(); instantanea = c ? { el: c, v: c.value } : null; }   // para deshacer las letras que se hayan escrito
    down[ev.code] = true;
    var k = Object.keys(down);
    if (k.length === 6 && k.every(function (x) { return CHORD[x]; }) && !ev.ctrlKey && !ev.altKey && !ev.metaKey && !ev.shiftKey) {
      ev.preventDefault(); down = {};
      if (instantanea && instantanea.el.value !== instantanea.v) { instantanea.el.value = instantanea.v; instantanea.el.dispatchEvent(new Event("input", { bubbles: true })); }
      alternar();
    }
  }, true);
  document.addEventListener("keyup", function (ev) { delete down[ev.code]; }, true);
  window.addEventListener("blur", function () { down = {}; });

  function alternar() {
    activo = !activo;
    try { sessionStorage.setItem("flow_admin_on", activo ? "1" : "0"); } catch (e) {}
    pintarChip();
    if (activo) abrir(); else cerrar();
    F.avisar(activo ? "Modo admin activado" : "Modo admin desactivado");
  }
  function pintarChip() {
    if (activo && !chip) {
      chip = boton("ADMIN", "admin-chip", abrir); chip.title = "Abrir el panel de administración";
      var cab = document.querySelector(".cabecera"); if (cab) cab.insertBefore(chip, document.getElementById("nuevoMovil"));
    } else if (!activo && chip) { chip.remove(); chip = null; }
  }

  /* ---------- panel ---------- */
  function cerrar() { if (fondo) { fondo.remove(); fondo = null; } editando = null; }
  function abrir() { cerrar(); fondo = h("div", "adm-fondo"); fondo.addEventListener("mousedown", function (ev) { if (ev.target === fondo) cerrar(); }); dibujar(); document.body.appendChild(fondo); }
  document.addEventListener("keydown", function (ev) { if (ev.key === "Escape" && fondo) cerrar(); });

  function host(u) { try { return new URL(u).host; } catch (e) { return u; } }
  function dibujar() {
    if (!fondo) return;
    fondo.textContent = "";
    var p = h("div", "adm"); p.setAttribute("role", "dialog"); p.setAttribute("aria-modal", "true"); p.setAttribute("aria-label", "Administración");
    var cab = h("div", "adm-cab"); cab.appendChild(h("h2", "", "Modo admin")); cab.appendChild(boton("Cerrar", "adm-b", cerrar)); p.appendChild(cab);
    p.appendChild(h("p", "adm-aviso", "Lo que cambies aquí se guarda solo en este navegador. Para que lo vean todos los visitantes hay que editar js/config.js y volver a publicar. Las claves que escribas quedan guardadas aquí, en texto, y cualquiera con acceso a este navegador podrá leerlas."));
    p.appendChild(seccionApis()); p.appendChild(seccionAjustes()); p.appendChild(seccionDatos());
    fondo.appendChild(p);
  }

  /* ----- APIs / modelos ----- */
  function seccionApis() {
    var s = h("section", "adm-sec"); s.appendChild(h("h3", "", "APIs y modelos"));
    var a = AD.leer(), propios = a.modelos.map(function (m) { return m.id; }), lista = AD.lista(), act = AD.actual();
    var ul = h("ul", "adm-lista");
    lista.forEach(function (m) {
      var li = h("li", "adm-fila"), info = h("div", "adm-info");
      var t = h("div", "adm-nombre", m.nombre); if (m.id === act) t.appendChild(h("span", "adm-etq", "en uso"));
      t.appendChild(h("span", "adm-etq gris", m.tipo === "flowpi" ? "Raspberry Pi" : "servidor antiguo")); t.appendChild(h("span", "adm-etq gris", propios.indexOf(m.id) >= 0 ? "añadida aquí" : "de config.js"));
      info.appendChild(t); info.appendChild(h("div", "adm-url", host(m.apiUrl) + (m.apiKey ? " · con clave" : " · sin clave")));
      var res = h("div", "adm-res"); res.setAttribute("aria-live", "polite"); info.appendChild(res);
      var ac = h("div", "adm-acc");
      ac.appendChild(boton("Probar", "adm-b", function () { probar(m, res); }));
      if (m.id !== act) ac.appendChild(boton("Usar", "adm-b", function () { AD.usarModelo(m.id); var x = AD.leer(); x.defecto = m.id; AD.guardar(x); dibujar(); }));
      ac.appendChild(boton("Editar", "adm-b", function () { editando = m; dibujar(); }));
      ac.appendChild(boton(propios.indexOf(m.id) >= 0 && AD.base().every(function (b) { return b.id !== m.id; }) ? "Borrar" : "Quitar", "adm-b peligro", function () { quitar(m); }));
      li.appendChild(info); li.appendChild(ac); ul.appendChild(li);
    });
    s.appendChild(ul);
    if (editando !== null) s.appendChild(formulario(editando)); else s.appendChild(boton("Añadir API", "adm-b principal", function () { editando = {}; dibujar(); }));
    return s;
  }
  function quitar(m) {
    var a = AD.leer(), esDeConfig = AD.base().some(function (b) { return b.id === m.id; });
    a.modelos = a.modelos.filter(function (x) { return x.id !== m.id; });
    if (esDeConfig && a.ocultos.indexOf(m.id) < 0) a.ocultos.push(m.id);      // las de config.js solo se ocultan en este navegador
    if (AD.lista().length <= 1 && AD.lista()[0].id === m.id && !a.modelos.length) { F.avisar("Tiene que quedar al menos una API."); return; }
    if (a.defecto === m.id) a.defecto = "";
    AD.guardar(a); AD.refrescar(); dibujar();
  }
  function campo(etq, input, ayuda) { var l = h("label", "adm-campo"); l.appendChild(h("span", "", etq)); l.appendChild(input); if (ayuda) l.appendChild(h("small", "", ayuda)); return l; }
  function formulario(m) {
    var nuevo = !m.id, f = h("form", "adm-form"); f.autocomplete = "off";
    var nombre = h("input"); nombre.value = m.nombre || ""; nombre.maxLength = 60; nombre.required = true; nombre.placeholder = "Mi Flow";
    var tipo = h("select"); [["flowpi", "Raspberry Pi (Flow Pi, /v1/chat)"], ["antiguo", "Servidor antiguo (PythonAnywhere, /chat)"]].forEach(function (o) { var op = h("option", "", o[1]); op.value = o[0]; tipo.appendChild(op); });
    tipo.value = m.tipo === "flowpi" || nuevo ? "flowpi" : "antiguo";
    var url = h("input"); url.type = "url"; url.value = m.apiUrl || ""; url.required = true; url.placeholder = "https://mi-pi.tu-red.ts.net:8443";
    var clave = h("input"); clave.type = "password"; clave.value = m.apiKey || ""; clave.autocomplete = "off"; clave.placeholder = "flw_…";
    var ver = boton("Ver", "adm-b chico", function () { clave.type = clave.type === "password" ? "text" : "password"; ver.textContent = clave.type === "password" ? "Ver" : "Ocultar"; });
    var fila = h("div", "adm-clave"); fila.appendChild(clave); fila.appendChild(ver);
    var etiq = h("input"); etiq.value = m.etiqueta || ""; etiq.maxLength = 12; etiq.placeholder = "XT";
    var det = h("input"); det.value = m.detalle || ""; det.maxLength = 80; det.placeholder = "modelo propio en español";
    var mod = h("input"); mod.value = m.modelo || ""; mod.placeholder = "id definido en modelos.json del servidor";
    var cMod = campo("Modelo del servidor (opcional)", mod);
    f.appendChild(campo("Nombre", nombre)); f.appendChild(campo("Tipo", tipo));
    f.appendChild(campo("Dirección (https)", url, "Con Tailscale Funnel incluye el puerto, p. ej. …ts.net:8443. Solo se admite http en localhost."));
    var cClave = h("label", "adm-campo"); cClave.appendChild(h("span", "", "Clave de API")); cClave.appendChild(fila); f.appendChild(cClave);
    f.appendChild(campo("Etiqueta corta", etiq)); f.appendChild(campo("Detalle", det)); f.appendChild(cMod);
    var err = h("p", "adm-error"); err.setAttribute("role", "alert"); f.appendChild(err);
    var bs = h("div", "adm-acc");
    var ok = h("button", "adm-b principal", nuevo ? "Añadir" : "Guardar"); ok.type = "submit"; bs.appendChild(ok);
    bs.appendChild(boton("Cancelar", "adm-b", function () { editando = null; dibujar(); })); f.appendChild(bs);
    var pintaTipo = function () { cMod.hidden = tipo.value === "flowpi"; }; tipo.addEventListener("change", pintaTipo); pintaTipo();
    f.addEventListener("submit", function (ev) {
      ev.preventDefault();
      var a = AD.leer(), id = m.id;
      if (!id) { var base = (nombre.value.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "api").slice(0, 30), n = 0; id = base;
        var usados = AD.lista().map(function (x) { return x.id; }).concat(a.ocultos); while (usados.indexOf(id) >= 0) id = base + "-" + (++n); }
      var obj = { id: id, nombre: nombre.value.trim(), etiqueta: etiq.value.trim(), detalle: det.value.trim(), apiUrl: url.value.trim(), apiKey: clave.value.trim() };
      if (tipo.value === "flowpi") obj.tipo = "flowpi"; else if (mod.value.trim()) obj.modelo = mod.value.trim();
      var limpio = AD.sanear(obj);
      if (!limpio) { err.textContent = "La dirección no es válida: tiene que empezar por https:// (o http://localhost)."; return; }
      if (!limpio.nombre) { err.textContent = "Ponle un nombre."; return; }
      a.modelos = a.modelos.filter(function (x) { return x.id !== id; }); a.modelos.push(limpio);
      a.ocultos = a.ocultos.filter(function (x) { return x !== id; });
      if (!AD.guardar(a)) { err.textContent = "No se pudo guardar (¿el navegador bloquea el almacenamiento?)."; return; }
      editando = null; AD.refrescar(); if (nuevo) AD.usarModelo(id); dibujar();
    });
    return f;
  }
  async function probar(m, res) {
    res.className = "adm-res"; res.textContent = "Probando…";
    var base = m.apiUrl.replace(/\/+$/, ""), ctl = new AbortController(), t = setTimeout(function () { ctl.abort(); }, 8000);
    try {
      if (m.tipo === "flowpi") {
        var r1 = await fetch(base + "/v1/health", { signal: ctl.signal }), d1 = await r1.json();
        if (d1.estado !== "listo") { res.className = "adm-res mal"; res.textContent = "La API responde pero no tiene modelo cargado."; return; }
        var r2 = await fetch(base + "/v1/models", { signal: ctl.signal, headers: m.apiKey ? { Authorization: "Bearer " + m.apiKey } : {} });
        if (r2.status === 401) { res.className = "adm-res mal"; res.textContent = "La API está en marcha pero la clave no vale."; return; }
        res.className = "adm-res bien"; res.textContent = r2.ok ? "Todo bien: API lista y clave válida." : "API lista (el control de la clave devolvió " + r2.status + ").";
      } else {
        var r3 = await fetch(base + "/", { signal: ctl.signal, headers: m.apiKey ? { "X-API-Key": m.apiKey } : {} });
        res.className = r3.status < 500 ? "adm-res bien" : "adm-res mal"; res.textContent = r3.status < 500 ? "El servidor responde (HTTP " + r3.status + ")." : "El servidor da error (HTTP " + r3.status + ").";
      }
    } catch (e) {
      res.className = "adm-res mal";
      res.textContent = e && e.name === "AbortError" ? "No responde (8 s). ¿La Pi está encendida y el Funnel activo?" : "No se pudo conectar. Mira la dirección, que el Funnel esté activo y que el origen de esta web esté permitido en el panel de la Pi (CORS).";
    } finally { clearTimeout(t); }
  }

  /* ----- ajustes ----- */
  function seccionAjustes() {
    var s = h("section", "adm-sec"); s.appendChild(h("h3", "", "Llamada y chat")); var aj = AD.leer().ajustes, L = C.llamada || {};
    var f = h("form", "adm-form");
    var saludo = h("input"); saludo.value = typeof aj.saludo === "string" ? aj.saludo : (L.saludo || ""); saludo.maxLength = 120;
    var idioma = h("input"); idioma.value = typeof aj.idioma === "string" ? aj.idioma : (L.idioma || "es-ES"); idioma.maxLength = 12;
    var voz = h("input"); voz.value = typeof aj.vozPreferida === "string" ? aj.vozPreferida : (L.vozPreferida || ""); voz.maxLength = 60; voz.placeholder = "p. ej. Alvaro|Elvira";
    var esf = h("select"); AD.esfuerzos().forEach(function (e) { var o = h("option", "", e); o.value = e; esf.appendChild(o); }); esf.value = aj.esfuerzoPorDefecto || C.esfuerzoPorDefecto || "alto";
    var efe = h("input"); efe.type = "checkbox"; efe.checked = typeof aj.efectoEscritura === "boolean" ? aj.efectoEscritura : C.efectoEscritura !== false;
    f.appendChild(campo("Saludo al descolgar", saludo, "Vacío = no dice nada.")); f.appendChild(campo("Idioma del micrófono", idioma));
    f.appendChild(campo("Voz preferida", voz, "Parte del nombre de una voz instalada; vacío = la más natural.")); f.appendChild(campo("Esfuerzo por defecto", esf));
    var l = h("label", "adm-check"); l.appendChild(efe); l.appendChild(h("span", "", "Mostrar la respuesta escribiéndose")); f.appendChild(l);
    var bs = h("div", "adm-acc"); var ok = h("button", "adm-b principal", "Guardar y recargar"); ok.type = "submit"; bs.appendChild(ok); f.appendChild(bs);
    f.addEventListener("submit", function (ev) {
      ev.preventDefault(); var a = AD.leer();
      a.ajustes = { saludo: saludo.value, idioma: idioma.value.trim() || "es-ES", vozPreferida: voz.value.trim(), esfuerzoPorDefecto: esf.value, efectoEscritura: efe.checked };
      AD.guardar(a); location.reload();
    });
    s.appendChild(f); return s;
  }

  /* ----- datos ----- */
  function seccionDatos() {
    var s = h("section", "adm-sec"); s.appendChild(h("h3", "", "Datos del admin")); var ac = h("div", "adm-acc");
    ac.appendChild(boton("Exportar (JSON)", "adm-b", function () {
      if (!confirm("El archivo incluirá las claves de API en texto. Guárdalo en un sitio privado. ¿Exportar?")) return;
      var b = new Blob([JSON.stringify(AD.leer(), null, 1)], { type: "application/json" }), u = URL.createObjectURL(b), a = h("a"); a.href = u; a.download = "flow-admin.json"; a.click(); setTimeout(function () { URL.revokeObjectURL(u); }, 2000);
    }));
    var inp = h("input"); inp.type = "file"; inp.accept = "application/json,.json"; inp.hidden = true;
    inp.addEventListener("change", function () {
      var fl = inp.files && inp.files[0]; if (!fl) return;
      fl.text().then(function (t) {
        var o = JSON.parse(t); if (!o || typeof o !== "object") throw 0;
        if (!AD.guardar(o)) throw 0; AD.refrescar(); dibujar(); F.avisar("Importado");
      }).catch(function () { F.avisar("No se pudo importar ese archivo."); });
    });
    ac.appendChild(boton("Importar (JSON)", "adm-b", function () { inp.click(); })); ac.appendChild(inp);
    ac.appendChild(boton("Borrar cambios del admin", "adm-b peligro", function () {
      if (!confirm("Se borran las APIs añadidas, las ocultas y los ajustes de este navegador. ¿Seguro?")) return;
      AD.guardar({ modelos: [], ocultos: [], defecto: "", ajustes: {} }); location.reload();
    }));
    ac.appendChild(boton("Salir del modo admin", "adm-b", alternar));
    s.appendChild(ac); return s;
  }

  pintarChip();
})();
